"""Wrapper akses Supabase untuk tabel `signals`."""
from datetime import datetime, timezone
from typing import Optional

from supabase import create_client, Client

import config

_client: Optional[Client] = None


def get_client() -> Client:
    global _client
    if _client is None:
        _client = create_client(config.SUPABASE_URL, config.SUPABASE_KEY)
    return _client


def insert_signal(*, message_id: int, chat_id: int, pair: str, symbol: str,
                   direction: str, entry: float, stoploss: float,
                   take_profit: float, rr: float, raw_message: str) -> dict:
    client = get_client()
    row = {
        "message_id": message_id,
        "chat_id": chat_id,
        "pair": pair,
        "symbol": symbol,
        "direction": direction,
        "entry": entry,
        "stoploss": stoploss,
        "take_profit": take_profit,
        "rr": rr,
        "status": "PENDING",
        "raw_message": raw_message,
    }
    res = client.table("signals").insert(row).execute()
    return res.data[0]


def get_open_signals() -> list[dict]:
    """Signal yang masih PENDING (nunggu entry) atau ACTIVE (nunggu SL/TP)."""
    client = get_client()
    res = (
        client.table("signals")
        .select("*")
        .in_("status", ["PENDING", "ACTIVE"])
        .execute()
    )
    return res.data


def mark_active(signal_id: int, price: float):
    client = get_client()
    client.table("signals").update({
        "status": "ACTIVE",
        "entry_hit_at": datetime.now(timezone.utc).isoformat(),
        "last_price": price,
    }).eq("id", signal_id).execute()


def close_signal(signal_id: int, *, status: str, result: str, price: float):
    client = get_client()
    client.table("signals").update({
        "status": status,
        "result": result,
        "last_price": price,
        "closed_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", signal_id).execute()


def update_last_price(signal_id: int, price: float):
    client = get_client()
    client.table("signals").update({"last_price": price}).eq("id", signal_id).execute()


def get_closed_signals_between(start_iso: str, end_iso: str) -> list[dict]:
    client = get_client()
    res = (
        client.table("signals")
        .select("*")
        .gte("closed_at", start_iso)
        .lt("closed_at", end_iso)
        .in_("status", ["TP_HIT", "SL_HIT"])
        .execute()
    )
    return res.data
