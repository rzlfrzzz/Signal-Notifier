"""Loop periodik yang cek harga MEXC dan update status signal:

PENDING -> ACTIVE   (harga menyentuh level entry)
ACTIVE  -> TP_HIT   (harga menyentuh take profit)  -> hasil WIN
ACTIVE  -> SL_HIT   (harga menyentuh stoploss)     -> hasil LOSS

Deteksi "menyentuh" pakai crossing check antara harga poll sebelumnya
dan harga sekarang, supaya tetap terdeteksi walau entry ada di atas
ATAU di bawah harga saat signal diposting.
"""
import logging

import config
import database
import mexc_client

logger = logging.getLogger(__name__)


def _crossed(prev: float | None, curr: float, level: float) -> bool:
    if prev is None:
        # Belum ada harga sebelumnya untuk dibandingkan -> anggap "hit" hanya
        # kalau harga sekarang PERSIS sudah lewati level saat pertama kali dicek.
        # Untuk entry, ini jarang kejadian; nanti poll berikutnya baru akurat
        # pakai crossing dari prev.
        return False
    return (prev - level) * (curr - level) <= 0


async def check_positions(bot, channel_id):
    open_signals = database.get_open_signals()
    if not open_signals:
        return

    symbols_needed = {s["symbol"] for s in open_signals}
    try:
        all_prices = await mexc_client.get_all_prices()
    except Exception as e:
        logger.warning("Gagal ambil harga MEXC: %s", e)
        return

    for sig in open_signals:
        symbol = sig["symbol"]
        curr = all_prices.get(symbol)
        if curr is None:
            continue

        prev = sig.get("last_price")

        if sig["status"] == "PENDING":
            if _crossed(prev, curr, sig["entry"]):
                database.mark_active(sig["id"], curr)
                await bot.send_message(
                    chat_id=channel_id,
                    text=(
                        f"🎯 ENTRY HIT — {sig['pair']} ({sig['direction']})\n"
                        f"Entry: {sig['entry']}\n"
                        f"Harga sekarang: {curr}\n"
                        f"SL: {sig['stoploss']} | TP: {sig['take_profit']} (RR 1:{sig['rr']:g})"
                    ),
                )
            else:
                database.update_last_price(sig["id"], curr)
            continue

        if sig["status"] == "ACTIVE":
            hit_tp = _crossed(prev, curr, sig["take_profit"])
            hit_sl = _crossed(prev, curr, sig["stoploss"])

            if hit_tp and hit_sl:
                # Kedua level ke-cross di poll yang sama (jarang, harga gap besar).
                # Utamakan yang lebih dekat dengan harga saat ini.
                if abs(curr - sig["take_profit"]) <= abs(curr - sig["stoploss"]):
                    hit_sl = False
                else:
                    hit_tp = False

            if hit_tp:
                database.close_signal(sig["id"], status="TP_HIT", result="WIN", price=curr)
                await bot.send_message(
                    chat_id=channel_id,
                    text=(
                        f"✅ TAKE PROFIT HIT — {sig['pair']} ({sig['direction']})\n"
                        f"Entry: {sig['entry']} -> TP: {sig['take_profit']}\n"
                        f"Result: WIN (RR 1:{sig['rr']:g})"
                    ),
                )
            elif hit_sl:
                database.close_signal(sig["id"], status="SL_HIT", result="LOSS", price=curr)
                await bot.send_message(
                    chat_id=channel_id,
                    text=(
                        f"🛑 STOPLOSS HIT — {sig['pair']} ({sig['direction']})\n"
                        f"Entry: {sig['entry']} -> SL: {sig['stoploss']}\n"
                        f"Result: LOSS"
                    ),
                )
            else:
                database.update_last_price(sig["id"], curr)


async def monitor_job(context):
    """Callback untuk python-telegram-bot JobQueue (run_repeating)."""
    await check_positions(context.bot, config.TELEGRAM_CHANNEL_ID)
