-- Jalankan ini di Supabase SQL Editor sebelum menjalankan bot

create table if not exists signals (
    id              bigserial primary key,
    message_id      bigint,
    chat_id         bigint,
    pair            text not null,          -- tampilan asli, mis. "RE/USDT"
    symbol          text not null,           -- symbol MEXC, mis. "REUSDT"
    direction       text not null check (direction in ('LONG','SHORT')),
    entry           numeric not null,
    stoploss        numeric not null,
    take_profit     numeric not null,
    rr              numeric not null default 3,
    status          text not null default 'PENDING',
                    -- PENDING -> ACTIVE -> TP_HIT | SL_HIT
                    -- (PENDING = entry belum kesentuh, ACTIVE = sudah entry, menunggu SL/TP)
    result          text,                    -- 'WIN' | 'LOSS' | null selama belum closed
    raw_message     text,
    last_price      numeric,
    created_at      timestamptz not null default now(),
    entry_hit_at    timestamptz,
    closed_at       timestamptz
);

create index if not exists idx_signals_status on signals(status);
create index if not exists idx_signals_symbol on signals(symbol);
create index if not exists idx_signals_closed_at on signals(closed_at);

-- (opsional) row level security kalau kamu pakai anon key dari client lain.
-- Bot memakai service_role key, jadi RLS tidak menghalangi bot ini.
-- alter table signals enable row level security;
