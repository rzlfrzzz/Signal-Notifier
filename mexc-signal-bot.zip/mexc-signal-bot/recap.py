"""Generate & kirim rekap harian / bulanan ke channel."""
from datetime import datetime, timedelta
import pytz

import config
import database

TZ = pytz.timezone(config.TIMEZONE)


def _format_recap(title: str, signals: list[dict]) -> str:
    total = len(signals)
    if total == 0:
        return f"{title}\n\nBelum ada signal yang closed pada periode ini."

    wins = [s for s in signals if s["result"] == "WIN"]
    losses = [s for s in signals if s["result"] == "LOSS"]
    win_rate = (len(wins) / total) * 100

    # Total RR: menang = +rr, kalah = -1 (risiko 1R)
    total_rr = sum(s["rr"] for s in wins) - len(losses)

    lines = [title, ""]
    lines.append(f"Total Signal : {total}")
    lines.append(f"✅ Win  : {len(wins)}")
    lines.append(f"🛑 Loss : {len(losses)}")
    lines.append(f"Win Rate : {win_rate:.1f}%")
    lines.append(f"Total RR : {total_rr:+.1f}R")
    lines.append("")
    lines.append("Detail:")
    for s in signals:
        icon = "✅" if s["result"] == "WIN" else "🛑"
        rr_text = f"+{s['rr']:g}R" if s["result"] == "WIN" else "-1R"
        lines.append(f"{icon} {s['pair']} ({s['direction']}) — {rr_text}")

    return "\n".join(lines)


async def send_daily_recap(bot, for_date: datetime | None = None):
    now_local = for_date or datetime.now(TZ)
    start_local = TZ.localize(datetime(now_local.year, now_local.month, now_local.day))
    end_local = start_local + timedelta(days=1)

    start_utc = start_local.astimezone(pytz.utc).isoformat()
    end_utc = end_local.astimezone(pytz.utc).isoformat()

    signals = database.get_closed_signals_between(start_utc, end_utc)
    title = f"📊 REKAP HARIAN — {start_local.strftime('%d %B %Y')}"
    text = _format_recap(title, signals)
    await bot.send_message(chat_id=config.TELEGRAM_CHANNEL_ID, text=text)


async def send_monthly_recap(bot, for_date: datetime | None = None):
    """Default: rekap BULAN SEBELUMNYA (dipanggil tanggal 1)."""
    now_local = for_date or datetime.now(TZ)
    first_of_this_month = now_local.replace(day=1)
    last_month_end = first_of_this_month
    last_month_start = (first_of_this_month - timedelta(days=1)).replace(day=1)

    start_local = TZ.localize(datetime(last_month_start.year, last_month_start.month, 1))
    end_local = TZ.localize(datetime(last_month_end.year, last_month_end.month, 1))

    start_utc = start_local.astimezone(pytz.utc).isoformat()
    end_utc = end_local.astimezone(pytz.utc).isoformat()

    signals = database.get_closed_signals_between(start_utc, end_utc)
    title = f"📅 REKAP BULANAN — {start_local.strftime('%B %Y')}"
    text = _format_recap(title, signals)
    await bot.send_message(chat_id=config.TELEGRAM_CHANNEL_ID, text=text)


async def daily_recap_job(context):
    await send_daily_recap(context.bot)


async def monthly_recap_job(context):
    await send_monthly_recap(context.bot)
