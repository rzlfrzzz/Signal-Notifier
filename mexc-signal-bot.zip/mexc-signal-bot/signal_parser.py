"""Parser untuk format signal trading di channel Telegram.

Mendukung dua variasi format contoh:

Format A:
    🔥 $RE/USDT (LONG) 🟢
    Entry : 0.6325
    Stoploss : 0.6000
    Target : on chart

Format B:
    🟢 LONG SIGNAL ↗️
    Pair: $NOM
    Entry: 0.002236
    Stop Loss: 0.001414

Jika RR tidak disebutkan eksplisit (mis. "RR 1:5"), pakai config.DEFAULT_RR.
Take Profit dihitung otomatis dari entry, stoploss, dan RR karena target
biasanya "on chart" (tidak berupa angka).
"""
import re
from dataclasses import dataclass
from typing import Optional

import config


@dataclass
class ParsedSignal:
    pair: str          # tampilan asli, mis. "RE/USDT"
    symbol: str         # symbol MEXC, mis. "REUSDT"
    direction: str       # "LONG" | "SHORT"
    entry: float
    stoploss: float
    take_profit: float
    rr: float


_DIRECTION_RE = re.compile(r"\b(LONG|SHORT)\b", re.IGNORECASE)
_PAIR_LABELED_RE = re.compile(r"Pair\s*:?\s*\$?([A-Za-z0-9]+)(?:\s*/\s*([A-Za-z]{2,6}))?", re.IGNORECASE)
_PAIR_DOLLAR_RE = re.compile(r"\$([A-Za-z0-9]+)(?:\s*/\s*([A-Za-z]{2,6}))?")
_ENTRY_RE = re.compile(r"Entry\s*:?\s*\$?\s*([0-9]*\.?[0-9]+)", re.IGNORECASE)
_SL_RE = re.compile(r"(?:Stop\s*-?\s*Loss|Stoploss|SL)\s*:?\s*\$?\s*([0-9]*\.?[0-9]+)", re.IGNORECASE)
_RR_RE = re.compile(r"RR\s*:?\s*1\s*:\s*([0-9]*\.?[0-9]+)", re.IGNORECASE)


def _normalize_symbol(ticker: str, quote: Optional[str]) -> tuple[str, str]:
    """Return (display_pair, mexc_symbol)."""
    ticker = ticker.upper().strip()
    quote = (quote or config.DEFAULT_QUOTE).upper().strip()
    display_pair = f"{ticker}/{quote}"
    symbol = f"{ticker}{quote}"
    return display_pair, symbol


def parse_signal(text: str) -> Optional[ParsedSignal]:
    """Coba parse pesan channel sebagai signal trading.

    Return None kalau pesan bukan signal (field wajib tidak ditemukan),
    supaya pesan lain di channel (pengumuman, dsb) tidak ikut ke-parse.
    """
    if not text:
        return None

    direction_match = _DIRECTION_RE.search(text)
    entry_match = _ENTRY_RE.search(text)
    sl_match = _SL_RE.search(text)

    if not (direction_match and entry_match and sl_match):
        return None

    pair_match = _PAIR_LABELED_RE.search(text) or _PAIR_DOLLAR_RE.search(text)
    if not pair_match:
        return None

    direction = direction_match.group(1).upper()
    ticker = pair_match.group(1)
    quote = pair_match.group(2)
    display_pair, symbol = _normalize_symbol(ticker, quote)

    try:
        entry = float(entry_match.group(1))
        stoploss = float(sl_match.group(1))
    except ValueError:
        return None

    rr_match = _RR_RE.search(text)
    rr = float(rr_match.group(1)) if rr_match else config.DEFAULT_RR

    risk = abs(entry - stoploss)
    if risk == 0:
        return None

    if direction == "LONG":
        take_profit = entry + rr * risk
    else:
        take_profit = entry - rr * risk

    return ParsedSignal(
        pair=display_pair,
        symbol=symbol,
        direction=direction,
        entry=entry,
        stoploss=stoploss,
        take_profit=take_profit,
        rr=rr,
    )
